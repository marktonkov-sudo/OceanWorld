package com.oceanworld.block;

import com.oceanworld.OceanWorld;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;

public class ModBlocks {
    public static final Block OCEANITE_ORE = register(
            "oceanite_ore",
            new Block(Block.Settings.copy(Blocks.DIAMOND_ORE).strength(4.0f, 6.0f)));

    private static Block register(String name, Block block) {
        Block result = Registry.register(RegistryKeys.BLOCK, OceanWorld.id(name), block);
        return result;
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.NATURAL).register(entries -> {
            entries.add(OCEANITE_ORE);
        });
    }
}
