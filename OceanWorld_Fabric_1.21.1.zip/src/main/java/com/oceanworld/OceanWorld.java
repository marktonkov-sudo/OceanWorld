package com.oceanworld;

import com.oceanworld.block.ModBlocks;
import com.oceanworld.item.ModItems;
import com.oceanworld.item.OceanGillsItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.registry.Registry;

public class OceanWorld implements ModInitializer {
    public static final String MOD_ID = "oceanworld";

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
                if (OceanGillsItem.isEnabled(player)) {
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.WATER_BREATHING, 40, 0, false, false, true));
                    player.addStatusEffect(new StatusEffectInstance(
                            StatusEffects.DOLPHINS_GRACE, 40, 0, false, false, true));
                }
            }
        });
    }
}
