package com.oceanworld.item;

import com.oceanworld.OceanWorld;
import com.oceanworld.block.ModBlocks;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.*;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;

public class ModItems {
    public static final Item OCEANITE = register(
            "oceanite", new Item(new Item.Settings()));

    public static final Item OCEAN_GILLS = register(
            "ocean_gills", new OceanGillsItem(new Item.Settings().maxCount(1)));

    private static Item register(String name, Item item) {
        return Registry.register(RegistryKeys.ITEM, OceanWorld.id(name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(OCEANITE);
        });
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.TOOLS).register(entries -> {
            entries.add(OCEAN_GILLS);
        });
    }
}
