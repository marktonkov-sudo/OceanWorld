package com.oceanworld.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class OceanGillsItem extends Item {
    private static final Set<UUID> ENABLED = ConcurrentHashMap.newKeySet();

    public OceanGillsItem(Settings settings) {
        super(settings);
    }

    public static boolean isEnabled(PlayerEntity player) {
        return ENABLED.contains(player.getUuid());
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        if (!world.isClient) {
            UUID id = player.getUuid();
            if (ENABLED.contains(id)) {
                ENABLED.remove(id);
                player.sendMessage(Text.literal("§bOcean Gills: §cOFF"), true);
            } else {
                ENABLED.add(id);
                player.sendMessage(Text.literal("§bOcean Gills: §aON"), true);
            }
        }
        return TypedActionResult.success(player.getStackInHand(hand), world.isClient);
    }
}
