# Ocean World

Minecraft Java Edition 1.21.1 Fabric starter mod.

## Included
- Oceanite Ore block
- Oceanite item
- Ocean Gills item
- Right-click Ocean Gills to toggle ON/OFF
- When ON: Water Breathing + Dolphin's Grace
- Basic English and Ukrainian names

## Build
Use Java 21 and Gradle:
./gradlew build

The finished mod jar will be in build/libs/.
